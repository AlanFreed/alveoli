The titlecaps package is intended for setting rich text into titling
capitals (in which the first character of words are capitalized).  It
automatically accounts for diacritical marks (like umlauts), national
symbols (like "ae"), punctuation, and font changing commands that alter
the appearance or size of the text.  It allows a list of predesignated
words to be protected as lower-cased, and also allows for titling
exceptions of various sorts.
